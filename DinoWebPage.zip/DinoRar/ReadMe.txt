Dino Wiki (it's a small wiki)

This is a web page designed on a topic I have been really intrested in recently,
It has cards for each dino featured and these act as buttons to open a modal,
The modal has an overview / genral information on the dino and a link to there actual wikapidia.


Dinos on the site:
    Majungasaurus
    T.Rex
    Spinosaurus
    Velociraptor
    Triceratops
    Giganotosaurus
    Chicken
    Ankylosaurus
    Brachiosaurus
    

Technoladgy used:
    I have imported Bootstrap 5.3.0 for the cards and modles 
    The main part of the file is html but has scripts and sets for css.
    No java script has been used as I could acomplish my goal and idea without it.

Run information:
    To run this site you simply need to open the html file in your browser
    You will also need a working web browser, firefox is recomeded as it was the browser used for testing.
    It has been tested to work on firefox, chrome and edge.

Extra info:
    It has been tested on android, due to some file system limitations the site workes however the images dont load.
    I have not been able to test it on any apple or ios divices as I do not have acsess to any. 
    